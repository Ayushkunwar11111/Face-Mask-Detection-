# Face_Mask_detection
If you want to learn step wise visit our YouTube channel https://youtu.be/IHcNj0Vs4fs

If anyone doesn't want to use Jupyter Notebook they can use any other tool as well

If you have any query contact us on : aiwithnur@gmail.com

Instagram: https://instagram.com/ai.with.nur?igshid=182rzcashsmec

Facebook: https://www.facebook.com/UrmiiNehaa/

Twitter: Take a look at Ai_with_NUR (@with_nur): https://twitter.com/with_nur?s=09
